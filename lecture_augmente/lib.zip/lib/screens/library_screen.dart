import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/reading_provider.dart';
import 'chapter_list_screen.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final books = context.watch<ReadingProvider>().books;

    if (books.isEmpty) {
      return const Center(
        child: Text('Aucun livre disponible pour le moment.'),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: books.length,
      itemBuilder: (context, index) {
        final book = books[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6),
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.menu_book)),
            title: Text(book.titre, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(book.auteur ?? 'Auteur inconnu'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChapterListScreen(livreId: book.id, titre: book.titre),
                ),
              );
            },
          ),
        );
      },
    );
  }
}