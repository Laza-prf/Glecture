import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/reading_provider.dart';
import '../providers/auth_provider.dart';
import 'library_screen.dart';
import 'login_screen.dart';
import 'add_book_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadBooks();
  }

  Future<void> _loadBooks() async {
    try {
      await context.read<ReadingProvider>().loadBooks();
    } catch (e) {
      _error = 'Impossible de charger les livres. Vérifie ton backend.';
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lecteur de Livres Augmenté'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(auth.isLoggedIn ? Icons.logout : Icons.login),
            tooltip: auth.isLoggedIn ? 'Déconnexion (${auth.nom})' : 'Se connecter',
            onPressed: () {
              if (auth.isLoggedIn) {
                auth.deconnexion();
              } else {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              }
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, size: 48, color: Colors.red),
                      const SizedBox(height: 12),
                      Text(_error!),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () {
                          setState(() => _isLoading = true);
                          _loadBooks();
                        },
                        child: const Text('Réessayer'),
                      ),
                    ],
                  ),
                )
              : const LibraryScreen(),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Ajouter un livre',
        onPressed: () {
          if (!auth.isLoggedIn) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const LoginScreen()),
            );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddBookScreen()),
            );
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}