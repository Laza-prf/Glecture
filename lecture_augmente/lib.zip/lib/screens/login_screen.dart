import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _modeInscription = false;
  final _nomController = TextEditingController();
  final _emailController = TextEditingController();
  final _motDePasseController = TextEditingController();
  bool _isLoading = false;
  String? _erreur;

  Future<void> _soumettre() async {
    setState(() {
      _isLoading = true;
      _erreur = null;
    });
    try {
      final auth = context.read<AuthProvider>();
      if (_modeInscription) {
        await auth.inscription(
          _nomController.text.trim(),
          _emailController.text.trim(),
          _motDePasseController.text,
        );
      } else {
        await auth.connexion(
          _emailController.text.trim(),
          _motDePasseController.text,
        );
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _erreur = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_modeInscription ? 'Créer un compte' : 'Connexion')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_modeInscription) ...[
              TextField(
                controller: _nomController,
                decoration: const InputDecoration(labelText: 'Nom'),
              ),
              const SizedBox(height: 12),
            ],
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _motDePasseController,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            if (_erreur != null) ...[
              const SizedBox(height: 12),
              Text(_erreur!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isLoading ? null : _soumettre,
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text(_modeInscription ? "S'inscrire" : 'Se connecter'),
            ),
            TextButton(
              onPressed: () => setState(() => _modeInscription = !_modeInscription),
              child: Text(_modeInscription
                  ? 'Déjà un compte ? Se connecter'
                  : 'Pas de compte ? S\'inscrire'),
            ),
          ],
        ),
      ),
    );
  }
}