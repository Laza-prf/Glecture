import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/reading_provider.dart';
import '../services/api_service.dart';

class AddBookScreen extends StatefulWidget {
  const AddBookScreen({super.key});

  @override
  State<AddBookScreen> createState() => _AddBookScreenState();
}

class _AddBookScreenState extends State<AddBookScreen> {
  final _titreController = TextEditingController();
  final _auteurController = TextEditingController();
  final ApiService _api = ApiService();

  PlatformFile? _fichier;
  bool _isUploading = false;
  String? _erreur;

  Future<void> _choisirFichier() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['txt', 'pdf'],
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => _fichier = result.files.first);
    }
  }

  Future<void> _envoyer() async {
    if (_titreController.text.trim().isEmpty) {
      setState(() => _erreur = 'Le titre est obligatoire');
      return;
    }
    if (_fichier == null || _fichier!.path == null) {
      setState(() => _erreur = 'Choisis un fichier .txt ou .pdf');
      return;
    }

    final token = context.read<AuthProvider>().token;
    if (token == null) {
      setState(() => _erreur = 'Connecte-toi avant d\'ajouter un livre');
      return;
    }

    setState(() {
      _isUploading = true;
      _erreur = null;
    });

    try {
      await _api.uploadLivre(
        titre: _titreController.text.trim(),
        auteur: _auteurController.text.trim(),
        filePath: _fichier!.path!,
        fileName: _fichier!.name,
        token: token,
      );
      if (mounted) {
        await context.read<ReadingProvider>().loadBooks();
        Navigator.pop(context);
      }
    } catch (e) {
      setState(() => _erreur = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajouter un livre')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titreController,
              decoration: const InputDecoration(labelText: 'Titre *'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _auteurController,
              decoration: const InputDecoration(labelText: 'Auteur'),
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: _choisirFichier,
              icon: const Icon(Icons.attach_file),
              label: Text(_fichier == null ? 'Choisir un fichier (.txt/.pdf)' : _fichier!.name),
            ),
            if (_erreur != null) ...[
              const SizedBox(height: 12),
              Text(_erreur!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isUploading ? null : _envoyer,
              child: _isUploading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Importer le livre'),
            ),
          ],
        ),
      ),
    );
  }
}