import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/book.dart';
import '../providers/reading_provider.dart';
import '../widgets/tappable_text.dart';
import '../widgets/summary_panel.dart';
import '../widgets/definition_popup.dart';

class ReaderScreen extends StatefulWidget {
  final List<ChapterSummary> chapitres;
  final int index;
  final String livreTitre;

  const ReaderScreen({
    super.key,
    required this.chapitres,
    required this.index,
    required this.livreTitre,
  });

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  late int _index;
  bool _isLoadingChapter = true;

  @override
  void initState() {
    super.initState();
    _index = widget.index;
    _loadChapter();
  }

  Future<void> _loadChapter() async {
    setState(() => _isLoadingChapter = true);
    await context
        .read<ReadingProvider>()
        .openChapter(widget.chapitres[_index].id);
    setState(() => _isLoadingChapter = false);
  }

  void _onWordTap(String word) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => DefinitionPopup(word: word),
    );
  }

  void _nextChapter() {
    if (_index < widget.chapitres.length - 1) {
      setState(() => _index++);
      _loadChapter();
    }
  }

  void _previousChapter() {
    if (_index > 0) {
      setState(() => _index--);
      _loadChapter();
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ReadingProvider>();
    final chapter = provider.currentChapter;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.livreTitre, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.auto_awesome),
            tooltip: 'Générer le résumé',
            onPressed: chapter == null
                ? null
                : () {
                    context.read<ReadingProvider>().generateSummary();
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      builder: (_) => const SummaryPanel(),
                    );
                  },
          ),
        ],
      ),
      body: _isLoadingChapter
          ? const Center(child: CircularProgressIndicator())
          : chapter == null
              ? const Center(child: Text('Chapitre introuvable.'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        chapter.titre.isNotEmpty
                            ? chapter.titre
                            : 'Chapitre ${chapter.numero}',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 12),
                      TappableText(
                        text: chapter.contenu,
                        onWordTap: _onWordTap,
                      ),
                    ],
                  ),
                ),
      bottomNavigationBar: BottomAppBar(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: _index > 0 ? _previousChapter : null,
                icon: const Icon(Icons.arrow_back),
                tooltip: 'Précédent',
              ),
              Flexible(
                child: Text(
                  '${_index + 1} / ${widget.chapitres.length}',
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ),
              IconButton(
                onPressed: _index < widget.chapitres.length - 1 ? _nextChapter : null,
                icon: const Icon(Icons.arrow_forward),
                tooltip: 'Suivant',
              ),
            ],
          ),
        ),
      ),
    );
  }
}